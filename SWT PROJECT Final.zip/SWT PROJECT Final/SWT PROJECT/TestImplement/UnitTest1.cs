using Microsoft.VisualStudio.TestPlatform.TestHost;
using Project_Library;

namespace TestImplement
{
    public class UnitTest1
    {

        /*[Fact]
        public void TestCaseID_01_AddAppointment_Successfully()
        {
            var appointmentToAdd = new Appointment { Id = "A004" };
            // Arrange
            AppointmentManager manager = new AppointmentManager();

            // Simulated console input (AppointmentID, PatientID, DoctorName, Slot)
            var fakeInput = new StringReader("DR.Tetelo202566\nMasokaKarabo2005\nDR.Tetelo\n2025-08-29 12:00\n");
            Console.SetIn(fakeInput);

            // Capture console output
            var fakeOutput = new StringWriter();
            Console.SetOut(fakeOutput);

            // Act
            manager.AddAppointment(appointmentToAdd);

            // Assert
            string output = fakeOutput.ToString();
            Assert.Contains("Appointment added successfully!", output);

            // Extra check: verify that appointment exists in manager's internal list
            // (using reflection since appointments list is protected)
            var appointmentsField = typeof(AppointmentManager)
                .GetField("appointments", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
            var appointments = appointmentsField?.GetValue(manager) as List<Appointment>;

            Assert.NotNull(appointments);
            Assert.Contains(appointments, a => a.Id == "DR.Tetelo202566" &&
                                               a.PatientID == "MasokaKarabo2005" &&
                                               a.DoctorName == "DR.Tetelo");
        }*/

        [Fact]
        public void DeleteAppointment_ShouldReturnTrue_WhenExistingAppointmentIsDeleted() //ensuring that deletion is successful
        {
            //Arrange: create a manager to add an appointment that is to be deleted
            var manager = new AppointmentManager();
            var appointmentToDelete = new Appointment { Id = "A004" };
            manager.AddAppointment(appointmentToDelete);

            //Act: calling the Delete method
            var result = manager.DeleteAppointment("A004");

            //Assert: Checking if the deletion was successful and the appointment is no longer there.
            Assert.True(result);
        }
        [Fact]
        //Negative test - non-existent ID
        public void DeleteAppointment_ShouldReturnFalse_WhenAppointmentIdDoesNotExist()
        {
            // Creating a manager with no appointments (Arrange)
            var manager = new AppointmentManager();

            //Act: attempting to delete an appointment that doesn't exist...
            var result = manager.DeleteAppointment("A005");

            //Assert - showing a result where the deletion can't happen because it does not exist
            Assert.Throws<EntityNotFoundException>(() => result);
            Assert.False(result);
        }
        [Fact]
        //testing ListAll(). First, positive testing: should print appointments when appointments exist
        public void ListAll_ShouldPrintAppointments_WhenAppointmentExist()
        {
            //Arrange: creating a manager, adding mock appointments and preparing to capture the console output
            var manager = new AppointmentManager();
            manager.AddAppointment(new Appointment { Id = "A006", PatientID = "P101" });
            manager.AddAppointment(new Appointment { Id = "A007", PatientID = "P102" });

            var stringWriter = new StringWriter();
            Console.SetOut(stringWriter);

            //Act section: call the ListAll() method showing that it will print the stringWriter
            manager.ListAll();

            //Assert: we ensure and check the output string for the expected text 
            var output = stringWriter.ToString();
            Assert.Contains("A006", output);
            Assert.Contains("P101", output);
            Assert.Contains("A007", output);
            Assert.Contains("P102", output);
        }
        [Fact]
        public void ListAll_ShouldPrint1Appointment_WhenAppointmentExist()
        {
            //Arrange: creating a manager and seeing if it can print only 1 appointment when added. Doesn't need many appointments for printing
            var manager = new AppointmentManager();
            manager.AddAppointment(new Appointment { Id = "A008", PatientID = "P103" });

            var stringWriter = new StringWriter();
            Console.SetOut(stringWriter);

            //Act section: call the ListAll() method showing that it will print the stringWriter
            manager.ListAll();

            //Assert: we ensure and check the output string for the expected text 
            var output = stringWriter.ToString();
            Assert.Contains("A008", output);
            Assert.Contains("P103", output);
        }

        [Fact]
        //Negative testing: showing if it can print an empty list
        public void ListAll_ShouldPrintNoAppointmentsMessage_WhenListIsEmpty()
        {
            //Arrange: Create a new empty manager and pepare for capture in the console output
            var manager = new AppointmentManager();
            var stringWriter = new StringWriter();
            Console.SetOut(stringWriter);

            //Act: Call the ListAll method on the empty string. Seeing if it would actually pull through
            manager.ListAll();

            //Assert: Check if the captured output string for the expected message
            var output = stringWriter.ToString();
            Assert.Contains("No appointments to diaplay.", output);
        }
    }
    public class AppointmentManagerTestAdd
    {

        [Theory]
        //We are using theroy because we want to test this method with different data inputs to assess the behaviour of this unit
        //valid data inputs
        [InlineData("DR.Tetelo202566", "MasokaKarabo2005", "DR.Tetelo", "2025-08-29 12:00")]
        //invalid appointment id
        [InlineData("500064", "MasokaKarabo2005", "DR.Tetelo", "2025-08-29 12:00")]
        //invalid slot format
        [InlineData("DR.Tetelo202566", "MasokaKarabo2005", "DR.Tetelo", "2025/08/29 12h00")]
        //invalid doctor name
        [InlineData("DR.Tetelo202566", "MasokaKarabo2005", "Masoka", "2025-08-29 12:00")]
        public void TestCaseID_01_AddAppointment_Successfully(string appointmentId, string patientId, string doctorName, string timeSlot)
        {
            // Arrange
            AppointmentManager manager = new AppointmentManager();
            var appointmentToAdd = new Appointment { Id = "DR.Tetelo202566" };
            // Simulated console input (AppointmentID, PatientID, DoctorName, Slot)
            var fakeInput = new StringReader($"{appointmentId}\n{patientId}\n{doctorName}\n{timeSlot}\n");
            Console.SetIn(fakeInput);

            // Capture console output
            var fakeOutput = new StringWriter();
            Console.SetOut(fakeOutput);

            // Act
            manager.AddAppointment(appointmentToAdd);

            //since the aapint list is private, reflection is used to access the contents of this list
            //to confirm that the manager.add() worked
            //var appointmentsField = typeof(AppointmentManager)
            //    .GetField("appointments", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
            //var appointments = appointmentsField?.GetValue(manager) as List<Appointment>;

            // Assert
            //Assert.NotNull(appointments);
            Assert.Contains("Appointment added successfully!", fakeOutput.ToString());
        }

    }

    public class AppointmentManagerTestUpdate
    {
        [Theory]
        //If id exists, then update can continue
        [InlineData("DR.Tetelo202566", "NewPatient", "NewDoctor", true)]
        //id does not exist. Tests if system will catch the id not existing
        [InlineData("689", "NewPatient", "NewDoctor", false)]
        // Assess the behaviour of the unit if the is null
        [InlineData("", "NewPatient", "NewDoctor", false)]
        public void TestCaseID_02_UpdateAppointment(string appointmentId, string newPatientId, string newDoctorName, bool shouldSucceed)
        {
            // Arrange
            var manager = new AppointmentManager();
            var appointmentToUpdate = new Appointment { Id = "689" };
            // Input data to be inputed, that list is not null
            var addInput = new StringReader($"DR.Tetelo202566\nPAT001\nDr. Smith\n2025-09-10 12:00\n");
            Console.SetIn(addInput);
            Console.SetOut(new StringWriter());
            manager.AddAppointment(appointmentToUpdate);

            // simulates user entering the new data should the id match the one already stored. This is what would be updated as the new data points
            var fakeInput = new StringReader($"{appointmentId}\n{newPatientId}\n{newDoctorName}\n");
            Console.SetIn(fakeInput);

            var fakeOutput = new StringWriter();
            Console.SetOut(fakeOutput);

            // Act and Assert
            if (shouldSucceed)
            {
                manager.Update();
                Assert.Contains("Appointment updated successfully!", fakeOutput.ToString());
            }
            else
            {
                Assert.Throws<EntityNotFoundException>(() => manager.Update());
            }
        }
    }
}