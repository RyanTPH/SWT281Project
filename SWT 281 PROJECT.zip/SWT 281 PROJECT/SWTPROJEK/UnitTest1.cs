using System;
using Xunit;
using System.IO;
using PRG281_Healthcare_Management_App;
using Microsoft.VisualStudio.TestPlatform.TestHost;


namespace SWTPROJEK
{
    public class UnitTest1
    {
       
        [Fact]
        public void TestCaseID_01()
        {
            //Arrange
               //an instance of AppointmentManager is created
               AppointmentManager manager = new AppointmentManager();
               Patient patientInfo = new Patient();
            var fakeInput = new StringReader("DR.Tetelo202566\nMasokaKarabo2005\nDR.Tetelo\n2025/08/29  12:00:00");
            Console.SetIn(fakeInput);

            //capture what the console prints
            var fakeOutput = new StringWriter();
            Console.SetOut(fakeOutput);
           

            //Act
            Program.Main(Array.Empty<string>());
            //Assert

            //validate that the appointment was scheduled successfully
            Assert.Contains("Appointment scheduled successfully", fakeOutput.ToString());
        }
    }
}