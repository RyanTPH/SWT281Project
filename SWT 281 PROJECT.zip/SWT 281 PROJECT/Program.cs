﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Security;
using System.Security.Cryptography;
using PRG281_Healthcare_Management_App;
using System.IO;

namespace PRG281_Healthcare_Management_App
{
    public class Security
    {
        public static string HashPassword(string password)
        {
            //SHA256 is a secure algorithm to help with entering passwords
            using (SHA256 sha256 = SHA256.Create())
            {
                //here we convert the password captured into a bunch of bytes
                byte[] passwordBytes = Encoding.UTF8.GetBytes(password);
                //the bytes are created to create the hash
                byte[] hashBytes = sha256.ComputeHash(passwordBytes);

                //convert the blended hash back into a string so it can be saved
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < hashBytes.Length; i++)
                {
                    builder.Append(hashBytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }

        public static string CreateOtp(int digits = 6)
        {
            var rnd = new Random();
            int min = (int)Math.Pow(10, digits - 1);
            int max = (int)Math.Pow(10, digits) - 1;
            return rnd.Next(min, max).ToString();
        }
    }

    //Custom Exception handling
    public class ValidationFailedException : Exception
    {
        public ValidationFailedException() { }
        public ValidationFailedException(string message) : base(message) { }
        public ValidationFailedException(string message, Exception inner) : base(message, inner) { }
    }

    public class EntityNotFoundException : Exception
    {
        public EntityNotFoundException() { }
        public EntityNotFoundException(string message) : base(message) { }
        public EntityNotFoundException(string message, Exception inner) : base(message) { }

    }
    public class AvailabilityConflictException : Exception
    {
        public AvailabilityConflictException() { }
        public AvailabilityConflictException(string message) : base(message) { }
        public AvailabilityConflictException(string message, Exception innerException) : base(message, innerException) { }

    }
    //parent class for all entities
    public abstract class Base
    {
        public string Id { get; set; } = "";

        // Default validation (can be overridden)
        public virtual bool ValidateData() => !string.IsNullOrWhiteSpace(Id);

        // Default print (should be overridden by children)
        public virtual void Print() => Console.WriteLine($"Entity {Id}");
    }


    // Interface for managers
    interface IManageable<T> where T : Base
    {
        void Add();
        void Update();
        void Delete();
        void ListAll();
    }
    // Entities
   public class Patient : Base
    {
        public string FirstName { get; set; } = "";
        public string LastName { get; set; } = "";
        public string Phone { get; set; } = "";
        public DateTime DateOfBirth { get; set; }


        // Override ValidateData to ensure all fields are filled
        public override bool ValidateData()
        {
            if(!base.ValidateData()) return false;

            if (string.IsNullOrWhiteSpace(FirstName) || string.IsNullOrWhiteSpace(LastName) || string.IsNullOrWhiteSpace(Phone) || DateOfBirth == default) 
            {
                return false;
            } 
            return true;
        }
        public override void Print()
        {
            Console.WriteLine($"{Id}: {FirstName} {LastName} | DOB: {(DateOfBirth == default ? "unknown" : DateOfBirth.ToString("yyyy-MM-dd"))} | Phone: {Phone}");
        }
    }
    // Appointment class
    public class Appointment : Base, IComparable<Appointment> 
    {
        public string PatientID { get; set; } = "";
        public string DoctorName { get; set; } = "";
        public DateTime Slot { get; set; }

        public override bool ValidateData()
        {
            if (!base.ValidateData()) return false;

            if(string.IsNullOrWhiteSpace(PatientID) || string.IsNullOrWhiteSpace(DoctorName))
            {
                return false;
            }

            if (Slot <= DateTime.Now)
            {
                return false;
            }
            return true;
        }
        // Override ValidateData to ensure all fields are filled
        public override void Print()
        {
            Console.WriteLine($"{Id}: Patient {PatientID} with Dr. {DoctorName} at {Slot.ToString("yyyy-MM-dd HH:mm")}");
        }
        public int CompareTo(Appointment other)
        {
            if (other == null)
            {
                return 1;
            }
            return this.Slot.CompareTo(other.Slot);
        }
    }
    public class AppointmentManager : IManageable<Appointment>
    {
        // A private list to hold Appointment objects in memory.
         protected readonly List<Appointment> appointments = new List<Appointment>();
        // Constant string for the file path to save and load appointment data.
        private const string filePath = "appointments.csv";
        
        public AppointmentManager()// Constructor: Loads existing appointments from the file when the manager is created.
        {
            LoadAppointments();
        }

        // Method to add a new appointment.
        public void Add()
        {
            Console.WriteLine("\n--- Add New Appointment ---");
            var newAppointment = new Appointment();

            // Get appointment details from the user.
            Console.Write("Appointment ID: ");
            newAppointment.Id = Console.ReadLine() ?? "";//returns empty string if null

            Console.Write("Patient ID:");
            newAppointment.PatientID = Console.ReadLine() ?? "";

            Console.Write("Doctor's Name: ");
            newAppointment.DoctorName = Console.ReadLine() ?? "";

            Console.Write("Appointment Slot (yyyy-MM-dd HH:mm): ");
            if (DateTime.TryParse(Console.ReadLine(), out DateTime slot))
            {
                newAppointment.Slot = slot;
            }
            else
            {
                // Throw a custom exception for invalid date/time format.
                throw new ValidationFailedException("Invalid date format. Please use yyyy-MM-dd HH:mm..");
            }
            if(appointments.Any(a => a.Id == newAppointment.Id))
            {
                throw new ValidationFailedException($"Appointment with ID {newAppointment.Id} already exists.");
            }
            // Check for scheduling conflicts before adding.
            if (IsConflict(newAppointment))
            {
                throw new AvailabilityConflictException("Scheduling conflict detected. The doctor is already booked at this time.");

            }
            // Validate the data using the ValidateData method in the Appointment class.
            if (!newAppointment.ValidateData())
            {
                throw new ValidationFailedException("Data is incomplete or invalid. All fields are required and the appointment must be in the future.");

            }
            // Add the new appointment to the list and save to the file.
            appointments.Add(newAppointment);
            SaveAppointments();
            Console.WriteLine("Appointment added successfully!");
        }

        // Method to update an existing appointment.
        public void Update()
        {
            Console.WriteLine("\n--- Update Appointment ---");
            Console.Write("Enter Appointment ID to update: ");
            string id = Console.ReadLine() ?? "";
            // Find the appointment by its ID.
            var appointmentToUpdate = appointments.FirstOrDefault(a => a.Id.Equals(id, StringComparison.OrdinalIgnoreCase));

            // Throw an exception if the appointment is not found.
            if (appointmentToUpdate == null)
            {
                throw new EntityNotFoundException($"Appointment with ID {id} not found.");
            }

            // Prompt the user for new details.
            Console.WriteLine($"Appointment found: {appointmentToUpdate.DoctorName}");
            Console.Write("Enter new Patient ID (or press Enter to keep current): ");
            string newPatientId = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(newPatientId))
            {
                appointmentToUpdate.PatientID = newPatientId;
            }

            Console.Write("Enter new Doctor's Name (or press Enter to keep current): ");
            string newDoctorName = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(newDoctorName))
            {
                appointmentToUpdate.DoctorName = newDoctorName;
            }

            Console.WriteLine("Appointment updated successfully!");
            SaveAppointments(); // Save changes to the file.
        }

        // Method to delete an appointment.
        public void Delete()
        {
            Console.WriteLine("\n--- Delete Appointment ---");
            Console.Write("Enter Appointment ID to delete: ");
            string id = Console.ReadLine() ?? "";
            // Find the appointment to be deleted.
            var appointmentToDelete = appointments.FirstOrDefault(a => a.Id.Equals(id, StringComparison.OrdinalIgnoreCase));

            // Throw an exception if the appointment is not found.
            if (appointmentToDelete == null)
            {
                throw new EntityNotFoundException($"Appointment with ID {id} is not found.");
            }

            // Remove the appointment from the list and save to the file.
            appointments.Remove(appointmentToDelete);
            SaveAppointments();
            Console.WriteLine("Appointment deleted successfully!");
        }

        // Method to list all appointments.
        public void ListAll()
        {
            Console.WriteLine("\n--- All Appointments ---");
            if (!appointments.Any())
            {
                Console.WriteLine("No appointments found.");
                return;
            }
            // Sort appointments by date before printing.
            var sortedAppointments = appointments.OrderBy(a => a.Slot);
            foreach (var appointment in sortedAppointments)
            {
                appointment.Print(); // Use the Print() method from the Appointment class.
            }
        }

        // Private helper method to check for appointment conflicts (same doctor at the same time).
        private bool IsConflict(Appointment newAppointment)
        {
            return appointments.Any(a => a.DoctorName.Equals(newAppointment.DoctorName, StringComparison.OrdinalIgnoreCase) && a.Slot == newAppointment.Slot);
        }

        // Private method to load appointments from a CSV file.
        public void LoadAppointments()
        {
            if (!File.Exists(filePath))
            {
                Console.WriteLine("Appointments data file not found. Starting with an empty list.");
                return;
            }

            try
            {
                var lines = File.ReadAllLines(filePath);
                foreach (var line in lines)
                {
                    var parts = line.Split(',');
                    if (parts.Length == 4)
                    {
                        // Parse the date and create a new Appointment object.
                        if (DateTime.TryParse(parts[3], out DateTime slot))
                        {
                            appointments.Add(new Appointment
                            {
                                Id = parts[0],
                                PatientID = parts[1],
                                DoctorName = parts[2],
                                Slot = slot
                            });
                        }
                    }
                }
                Console.WriteLine($"Successfully loaded {appointments.Count} appointments.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error loading appointments data: {ex.Message}");
            }
        }

        // Private method to save the current appointments list to a CSV file.
        private void SaveAppointments()
        {
            try
            {
                var lines = new List<string>();
                foreach (var appointment in appointments)
                {
                    // Format the appointment data into a CSV string.
                    lines.Add($"{appointment.Id},{appointment.PatientID},{appointment.DoctorName},{appointment.Slot:yyyy-MM-dd HH:mm}");
                }
                File.WriteAllLines(filePath, lines); // Overwrite the file with the current data.
                Console.WriteLine("Appointments data saved successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error saving appointments data: {ex.Message}");
            }
        }
    }
    //Notification and scheduler classes creation
    public class NotificationService
    {
        public void SendAppointmentConfirmation(Appointment appointment)
        {
            Console.WriteLine($"Notification: A confirmation for Appointment ID {appointment.Id} for patient {appointment.PatientID} has been sent.");
        }
        public void SendAppointmentReminder(Appointment appointment)
        {
            Console.WriteLine($"Notification: A reminder for Appointment ID {appointment.Id} for patient {appointment.PatientID} has been sent.");
        }
    }
    public class AppointmentScheduler
    {
        private readonly NotificationService notificationService = new NotificationService();
        public void BookAppointment(Appointment appointment)
        {
            //linking the patient with the foctor for the appointment booking.
            Console.WriteLine($"Booking a new apointment for Patient Id {appointment.PatientID} with Dr. {appointment.DoctorName}.");

            //confirmation of the notification with Notification class
            notificationService.SendAppointmentConfirmation(appointment);
        }
    }
    class MedicalRecords : Base
    {
        public string PatientID { get; set; } = "";
        public string Diagnosis { get; set; } = "";
        public string TreatmentPlan { get; set; } = "";
        public DateTime DateOfEntry { get; set; }

        public override bool ValidateData()
        {
            if (!base.ValidateData()) return false;

            if (string.IsNullOrWhiteSpace(PatientID) || string.IsNullOrWhiteSpace(Diagnosis) || string.IsNullOrWhiteSpace(TreatmentPlan) || DateOfEntry == default)
            {
                return false;
            }
            return true;
        }
        // Override ValidateData to ensure all fields are filled
        public override void Print()
        {
            Console.WriteLine($"{Id}: Patient {PatientID} - Diagnosis {Diagnosis}, Treatment: {TreatmentPlan}, Date: {DateOfEntry.ToShortDateString()}");
        }
    }
    public class MedicalRecordManager : IManageable<MedicalRecords>
    {
        // A private list to hold Medical Record objects in memory.
        private readonly List<MedicalRecords> records = new List<MedicalRecords>();
        // Constant string for the file path to save and load appointment data.
        private const string filePath = "medical_records.csv";

        public MedicalRecordManager()// Constructor: Loads existing appointments from the file when the manager is created.
        {
            LoadRecords();
        }

        // Method to add a new appointment.
        public void Add()
        {
            Console.WriteLine("\n--- Add New Medical Record ---");
            var newRecord = new MedicalRecords();

            // Get appointment details from the user.
            Console.Write("Record ID: ");
            newRecord.Id = Console.ReadLine() ?? "";

            Console.Write("Patient ID:");
            newRecord.PatientID = Console.ReadLine() ?? "";

            Console.Write("Diagnosis: ");
            newRecord.Diagnosis = Console.ReadLine() ?? "";
            Console.Write("Treatment Plan: ");
            newRecord.TreatmentPlan = Console.ReadLine() ?? "";

            newRecord.DateOfEntry = DateTime.Now;
            if (!newRecord.ValidateData())
            {
                throw new ValidationFailedException($"Medical record data is incomplete. All fields are required.");
            }

            if (records.Any(r => r.Id == newRecord.Id))
            {
                throw new ValidationFailedException($"Record with ID {newRecord.Id} already exists");
            }
            records.Add(newRecord);
            SaveRecords();
            Console.WriteLine("Medical record added successfully!");
        }
        // Method to update an existing appointment.
        public void Update()
        {
            Console.WriteLine("\n--- Update Medical Record ---");
            Console.Write("Enter Record ID to update: ");
            string id = Console.ReadLine() ?? "";
            // Find the appointment by its ID.
            var recordToUpdate = records.FirstOrDefault(r => r.Id.Equals(id, StringComparison.OrdinalIgnoreCase));

            // Throw an exception if the appointment is not found.
            if (recordToUpdate == null)
            {
                throw new EntityNotFoundException($"Medical record with ID {id} not found.");
            }

            // Prompt the user for new details.
            Console.WriteLine($"Record found: {recordToUpdate.Diagnosis} for patient {recordToUpdate.PatientID}");
            Console.Write("Enter new Diagnosis (or press Enter to keep current): ");
            string newDiagnosis = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(newDiagnosis))
            {
                recordToUpdate.PatientID = newDiagnosis;
            }

            Console.Write("Enter new Treatment Plan (or press Enter to keep current): ");
            string newTreatment = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(newTreatment))
            {
                recordToUpdate.TreatmentPlan = newTreatment;
            }

            SaveRecords(); // Save changes to the file.
            Console.WriteLine("Appointment updated successfully!");
        }
        // Method to delete an appointment.
        public void Delete()
        {
            Console.WriteLine("\n--- Delete Medical Record ---");
            Console.Write("Enter Record ID to delete: ");
            string id = Console.ReadLine() ?? "";
            // Find the appointment to be deleted.
            var recordToDelete = records.FirstOrDefault(r => r.Id.Equals(id, StringComparison.OrdinalIgnoreCase));

            // Throw an exception if the appointment is not found.
            if (recordToDelete == null)
            {
                Console.WriteLine("Not found.");
                return;
            }

            // Remove the appointment from the list and save to the file.
            records.Remove(recordToDelete);
            SaveRecords();
            Console.WriteLine("Medical Record deleted successfully!");
        }
        // Method to list all appointments.
        public void ListAll()
        {
            Console.WriteLine("\n--- All Medical Records ---");
            if (!records.Any())
            {
                Console.WriteLine("No medical records found.");
                return;
            }
            foreach (var record in records)
            {
                record.Print(); // Use the Print() method from the Appointment class.
            }
        }
        // Private method to load appointments from a CSV file.
        private void LoadRecords()
        {
            if (!File.Exists(filePath))
            {
                Console.WriteLine("Medical records data file not found. Starting with an empty list.");
                return;
            }

            try
            {
                var lines = File.ReadAllLines(filePath);
                foreach (var line in lines)
                {
                    var parts = line.Split(',');
                    if (parts.Length == 5)
                    {
                        // Parse the date and create a new Appointment object.
                        if (DateTime.TryParse(parts[4], out DateTime dateOfEntry))
                        {
                            records.Add(new MedicalRecords
                            {
                                Id = parts[0],
                                PatientID = parts[1],
                                Diagnosis = parts[2],
                                TreatmentPlan = parts[3],
                                DateOfEntry = dateOfEntry
                            });
                        }
                    }
                }
                Console.WriteLine($"Successfully loaded {records.Count} appointments.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error loading medical records data: {ex.Message}");
            }
        }
        // Private method to save the current appointments list to a CSV file.
        private void SaveRecords()
        {
            try
            {
                var lines = new List<string>();
                foreach (var record in records)
                {
                    // Format the appointment data into a CSV string.
                    lines.Add($"{record.Id},{record.PatientID},{record.Diagnosis}, {record.TreatmentPlan}{record.DateOfEntry:yyyy-MM-dd HH:mm}");
                }
                File.WriteAllLines(filePath, lines); // Overwrite the file with the current data.
                Console.WriteLine("Medical records data saved successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error saving medical records data: {ex.Message}");
            }
        }
    }
    class PatientManager : IManageable<Patient>
    {
        //adding FileMonitor thread and custom events
        public delegate void DataChangedHandler(object sender, string message);
        public event DataChangedHandler OnDataChanged;


        // List to store patients
        private readonly List<Patient> patients = new List<Patient>();
        private const string filePath = "patients.csv";

        public PatientManager()
        {
            LoadPatients();
        }

        // Implementing IManageable methods
        public void Add()
        {

            var newPatient = new Patient();
            Console.Write("Patient ID: ");
            newPatient.Id = Console.ReadLine() ?? "";
            if (patients.Any(p=> p.Id == newPatient.Id))
            {
                throw new ValidationFailedException($"Patient with ID {newPatient.Id} already exists.");
            }

            Console.Write("First name: ");
            newPatient.FirstName = Console.ReadLine() ?? "";
            Console.Write("Last name: ");
            newPatient.LastName = Console.ReadLine() ?? "";
            Console.Write("Phone: ");
            newPatient.Phone = Console.ReadLine() ?? "";
            Console.Write("Date of birth (yyyy-MM-dd): ");
            string dobString = Console.ReadLine() ?? "";
            DateTime dob;
            if (!DateTime.TryParse(dobString, out dob))
            {
                throw new ValidationFailedException("Invalid Date of birth format. Please use yyyy-MM-dd.");
            }
            newPatient.DateOfBirth = dob;

            if (!newPatient.ValidateData())
            {
                throw new ValidationFailedException("Patient data is incomplete of invalid. All fields must be filled.");
            }

            patients.Add(newPatient);
            SavePatients();

            Console.WriteLine("Patient added!");
            TriggerDataChangedEvent($"Patient {newPatient.Id} added.");
        }
        // Update method to modify existing patient details
        public void Update()
        {
            Console.Write("Enter patient ID: ");
            // Prompt for patient ID to update
            var id = Console.ReadLine() ?? "";
            var patient = patients.Find(x => x.Id == id);
            // If patient not found, display message and return
            if (patient == null)
            {
                //attempting the custom exception
                throw new EntityNotFoundException($"Patient with ID: {id} is not found.");
                
            }
            Console.Write("New First Name: (or press Enter to skip) ");
            string newFirstName = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(newFirstName))
            {
                patient.FirstName = newFirstName;
            }

            Console.Write("New Last Name: (or press Enter to skip) ");
            string newLastName = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(newLastName))
            {
                patient.LastName = newLastName;
            }

            Console.Write("New First Name: (or press Enter to skip) ");
            string newPhone = Console.ReadLine();
            if (!string.IsNullOrWhiteSpace(newPhone))
            {
                patient.Phone = newPhone;
            }

            Console.WriteLine("Patient updated!");
            SavePatients();
            TriggerDataChangedEvent($"Patient {patient.Id} updated.");
        }
        // Delete method to remove a patient from the list
        public void Delete()
        {
            Console.Write("Enter patient ID: ");
            string id = Console.ReadLine() ?? "";
            // Find the patient by ID
            var patient = patients.Find(x => x.Id == id);
            if (patient == null)
            {
                //attempting custom exception

                throw new EntityNotFoundException($"Patient with ID: {id} is not found.");
            }
            patients.Remove(patient);
            Console.WriteLine("Patient deleted!");
            SavePatients();
            TriggerDataChangedEvent($"Patient {patient.Id} deleted.");
        }

        public void ListAll()
        {
            Console.WriteLine("--- All patients ---");
            if (!patients.Any()) 
            {
                Console.WriteLine("No patients found.");
                return;
            }
            foreach (var patient in patients) 
            {
                patient.Print();
            } 
        }

        private void TriggerDataChangedEvent(string message)
        {
            OnDataChanged?.Invoke(this, message);
        }

        private void LoadPatients()
        {
            if (!File.Exists(filePath))
            {
                Console.WriteLine("Patient data file not found. Starting with an empty list.");
                return;
            }

            try
            {
                var lines = File.ReadAllLines(filePath);
                foreach (var line in lines)
                {
                    var parts = line.Split(',');
                    if (parts.Length == 5)
                    {
                        if (DateTime.TryParse(parts[4], out DateTime dob))
                        {
                            patients.Add(new Patient
                            {
                                Id = parts[0],
                                FirstName = parts[1],
                                LastName = parts[2],
                                Phone = parts[3],
                                DateOfBirth = dob
                            });
                        }
                    }
                }
                Console.WriteLine($"Successfully loaded {patients.Count} patients.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error loading patient data: {ex.Message}");
            }
        }

        private void SavePatients()
        {
            try
            {
                var lines = new List<string>();
                foreach (var patient in patients)
                {
                    lines.Add($"{patient.Id},{patient.FirstName},{patient.LastName},{patient.Phone},{patient.DateOfBirth:yyyy-MM-dd}");
                }
                File.WriteAllLines(filePath, lines);
                Console.WriteLine("Patient data saved successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error saving patient data: {ex.Message}");
            }
        }
        

    }

    public class EmployeeCredentials
    {
        public void SignUp(string username, string password)
        {
            //scramble password into the HashPassword
            string hashedPassword = Security.HashPassword(password);

            //able to save the password and username 
            SaveCredentialsToFile(username, hashedPassword);

            Console.WriteLine("Sign up successful");
        }

        public bool login(string username, string password)
        {
            string filePath = "employee_credentials.txt";
            if (System.IO.File.Exists(filePath))
            {
                string[] lines = System.IO.File.ReadAllLines(filePath);
                foreach (string line in lines)
                {
                    string[] parts = line.Split(',');
                    if (parts.Length == 2 && parts[0] == username)
                    {
                        string storedHashedPassword = parts[1];

                        //Hash the password the user entered for comparison
                        string enteredHashedPassword = Security.HashPassword(password);

                        if (storedHashedPassword == enteredHashedPassword)
                        {
                            return true; //password match. The login is successful
                        }

                    }
                }
            }
            return false; //login failed
        }

        public void SaveCredentialsToFile(string username, string hashedPassword)
        {
            string filePath = "employee_credentials.txt";
            string userData = $"{username},{hashedPassword}";
            System.IO.File.AppendAllText(filePath, userData + Environment.NewLine);
        }
    }
    //creation of the FileMonitor class for tracking any background changes in the file changes.
    public class FileMonitor
    {
        private FileSystemWatcher watcher;
        private Thread monitorThread;
        private readonly string filePath;

        public FileMonitor(string path)
        {
            filePath = path;
        }
        public void StartMonitoring()
        {
            watcher = new FileSystemWatcher(Path.GetDirectoryName(filePath));
            watcher.Filter = Path.GetFileName(filePath);
            watcher.NotifyFilter = NotifyFilters.LastWrite;
            watcher.Changed += OnFileChanged;
            watcher.EnableRaisingEvents = true;

            monitorThread = new Thread(() =>
            {
                Console.WriteLine($"File monitoring started for {filePath}...");
                while (watcher.EnableRaisingEvents)
                {
                    Thread.Sleep(2500);
                }
            });
            monitorThread.IsBackground = true;
            monitorThread.Start();
        }
        private void OnFileChanged(object sender, FileSystemEventArgs e)
        {
            //The event DateChanged will be triggered from the relevant manager
            Console.WriteLine($"File '{e.FullPath}' was changed. Reloading data..");
        }
    }
    
    
}

internal class Program
{
    // Static instance of EmployeeCredentials to manage employee logins
    static EmployeeCredentials employeeManager = new EmployeeCredentials();

    static PatientManager patientmanager = new PatientManager();

    static AppointmentManager appointmentManager = new AppointmentManager();

    static MedicalRecordManager medicalRecordManager = new MedicalRecordManager();
    static void Main(string[] args)
    {
        Console.WriteLine("Welcome to the Healthcare Patient Management System!");
        bool running = true;
        while (running) //menu is created for the "homepage". The employee can pick out of the 3 options
        {
            Console.WriteLine("\n---Main menu---");
            Console.WriteLine("1. Sign up");
            Console.WriteLine("2. Log in");
            Console.WriteLine("3. Exit");
            Console.WriteLine("Enter your choice:");

            string choice = Console.ReadLine();
            switch (choice)
            {
                case "1":
                    SignUpUser();
                    break;
                case "2":
                    LoginUser();
                    break;
                case "3":
                    running = false;
                    Console.WriteLine("Existing application. Goodbye!");
                    break;
                default:
                    Console.WriteLine("Invalid choice. Please try again.");
                    break;
            }

        }

    }

    // SignUpUser method to handle user registration
    static void SignUpUser()
    {
        Console.Write("Enter your username: ");
        string username = Console.ReadLine();
        Console.Write("Enter your email: ");
        string email = Console.ReadLine();
        Console.Write("Enter your password: ");
        string password = Console.ReadLine();
        var otp = Security.CreateOtp();
        Console.WriteLine($"OTP (simulated): {otp}");
        Console.Write("Enter OTP: ");

        if ((Console.ReadLine() ?? "") != otp)
        {
            Console.WriteLine("OTP failed.");
            return;
        }

        // Check if username and password are not empty
        if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
        {
            Console.WriteLine("Username and password cannot be empty");
            return;
        }
        //use try and catch to ensure that either logins/signups are successful
        try
        {
            employeeManager.SignUp(username, password);
            Console.WriteLine("Sign up successful! Please log in"); //login is successful with try (optimism outcome)
        }
        catch (Exception ex)
        {
            Console.WriteLine($"An error occured during sign up: {ex.Message}"); //this is where the sign up is unsuccessful, requirements weren't met
        }
    }

    static void LoginUser()
    {
        Console.Write("Enter username:");
        string username = Console.ReadLine();
        Console.Write("Enter password:");
        string password = Console.ReadLine();

        try //what we did for the sign up, we do the same for the login. Here, the user's details have already been inserted
        {
            if (employeeManager.login(username, password))
            {
                Console.WriteLine("Login successful. Welcome to the Admin page.");
                ShowAdminPage();
            }
            else
            {
                Console.WriteLine("Login failed. Invalid username or password.");
            }
        }
        catch (UnauthorizedAccessException ex)
        {
            Console.WriteLine($"Login failed: {ex.Message}");
        }
    }

    static void ShowAdminPage() //creation of admin page
    {
        PatientManager patientManager = new PatientManager();

        bool isAdminPage = true;
        while (isAdminPage)
        {
            Console.WriteLine("\n--- Admin Page ---");
            Console.WriteLine("You have successfully accessed the main system");
            Console.WriteLine("Choose the actions you want to perform");
            Console.WriteLine("1. Patient Management");
            Console.WriteLine("2. Appointment Management");
            Console.WriteLine("3. Medical Record Management");
            Console.WriteLine("4. Logout");
            Console.WriteLine("Enter your choice: ");

            string choice = Console.ReadLine();
            try
            {
                switch (choice)
                {
                    case "1":
                        ManagePatients(patientManager);
                        break;
                    case "2":
                        ManageAppointments();
                        break;
                    case "3":
                        ManageMedicalRecords();
                        break;
                    case "4":
                        isAdminPage = false;
                        Console.WriteLine("Logging out...");
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again");
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected Error: {ex.Message}");
            }
        }
    }

    static void ManagePatients(PatientManager manager)
    {
        bool isManagingPatients = true;
        while (isManagingPatients)
        {
            Console.WriteLine("\n--- Patient Management ---");
            Console.WriteLine("1. Add patient");
            Console.WriteLine("2. Update Patient");
            Console.WriteLine("3. Delete patient");
            Console.WriteLine("4. List All patients");
            Console.WriteLine("5. Back to Admin Page");
            Console.WriteLine("Enter your choice");

            string choice = Console.ReadLine();

            try
            {
                switch (choice)
                {
                    case "1":
                        manager.Add();
                        break;
                    case "2":
                        manager.Update();
                        break;
                    case "3":
                        manager.Delete();
                        break;
                    case "4":
                        manager.ListAll();
                        break;
                    case "5":
                        isManagingPatients = false;
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
            catch (ValidationFailedException ex)
            {
                Console.WriteLine($"Validation error occured: {ex.Message}");
            }
            catch (EntityNotFoundException ex)
            {
                Console.WriteLine($"Operation error occured: {ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An unexpected error occured: {ex.Message}");
            }
        }
    }

    static void ManageAppointments()
    {
        bool isManagingAppointments = true;
        while (isManagingAppointments)
        {
            Console.WriteLine("\n--- Appointment Management ---");
            Console.WriteLine("1. Add Appointment");
            Console.WriteLine("2. Update Appointment");
            Console.WriteLine("3. Delete Appointment");
            Console.WriteLine("4. List All Appointments");
            Console.WriteLine("5. Back to Admin Page");
            Console.WriteLine("Enter your choice");

            string choice = Console.ReadLine();

            try
            {
                switch (choice)
                {
                    case "1":
                        appointmentManager.Add();
                        break;
                    case "2":
                        appointmentManager.Update();
                        break;
                    case "3":
                        appointmentManager.Delete();
                        break;
                    case "4":
                        appointmentManager.ListAll();
                        break;
                    case "5":
                        isManagingAppointments = false;
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An unexpected error occured: {ex.Message}");
            }
        }
    }
    static void ManageMedicalRecords()
    {
        bool isManagingRecords = true;
        while (isManagingRecords)
        {
            Console.WriteLine("\n--- Medical Records Management ---");
            Console.WriteLine("1. Add Medical Record");
            Console.WriteLine("2. Update Medical Record");
            Console.WriteLine("3. Delete Medical Record");
            Console.WriteLine("4. List All Medical Record");
            Console.WriteLine("5. Back to Admin Page");
            Console.WriteLine("Enter your choice");

            string choice = Console.ReadLine();

            try
            {
                switch (choice)
                {
                    case "1":
                        medicalRecordManager.Add();
                        break;
                    case "2":
                        medicalRecordManager.Update();
                        break;
                    case "3":
                        medicalRecordManager.Delete();
                        break;
                    case "4":
                        medicalRecordManager.ListAll();
                        break;
                    case "5":
                        isManagingRecords = false;
                        break;
                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
            catch (ValidationFailedException ex)
            {
                Console.WriteLine($"Validation error: {ex.Message}");
            }
            catch (EntityNotFoundException ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"An unexpected error occured: {ex.Message}");
            }
        }
    }
}
