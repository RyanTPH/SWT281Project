using Microsoft.VisualStudio.TestPlatform.TestHost;
using Project_Library;

namespace TestImplement
{
    public class UnitTest1
    {
       
        [Fact]
        public void TestCaseID_01_AddAppointment_Successfully()
        {
            // Arrange
            AppointmentManager manager = new AppointmentManager();

            // Simulated console input (AppointmentID, PatientID, DoctorName, Slot)
            var fakeInput = new StringReader("DR.Tetelo202566\nMasokaKarabo2005\nDR.Tetelo\n2025-08-29 12:00\n");
            Console.SetIn(fakeInput);

            // Capture console output
            var fakeOutput = new StringWriter();
            Console.SetOut(fakeOutput);

            // Act
            manager.Add();

            // Assert
            string output = fakeOutput.ToString();
            Assert.Contains("Appointment added successfully!", output);

            // Extra check: verify that appointment exists in manager's internal list
            // (using reflection since appointments list is protected)
            var appointmentsField = typeof(AppointmentManager)
                .GetField("appointments", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
            var appointments = appointmentsField?.GetValue(manager) as List<Appointment>;

            Assert.NotNull(appointments);
            Assert.Contains(appointments, a => a.Id == "DR.Tetelo202566" &&
                                               a.PatientID == "MasokaKarabo2005" &&
                                               a.DoctorName == "DR.Tetelo");
        }

    }
}