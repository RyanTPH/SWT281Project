using Microsoft.VisualStudio.TestPlatform.TestHost;
using Project_Library;

namespace TestImplement
{
    public class UnitTest1
    {

        [Fact]
        public void TestCaseID_01_AddAppointment_Successfully()
        {
            var appointmentToAdd = new Appointment { Id = "A004" };
            // Arrange
            AppointmentManager manager = new AppointmentManager();

            // Simulated console input (AppointmentID, PatientID, DoctorName, Slot)
            var fakeInput = new StringReader("DR.Tetelo202566\nMasokaKarabo2005\nDR.Tetelo\n2025-08-29 12:00\n");
            Console.SetIn(fakeInput);

            // Capture console output
            var fakeOutput = new StringWriter();
            Console.SetOut(fakeOutput);

            // Act
            manager.AddAppointment(appointmentToAdd);

            // Assert
            string output = fakeOutput.ToString();
            Assert.Contains("Appointment added successfully!", output);

            // Extra check: verify that appointment exists in manager's internal list
            // (using reflection since appointments list is protected)
            var appointmentsField = typeof(AppointmentManager)
                .GetField("appointments", System.Reflection.BindingFlags.NonPublic | System.Reflection.BindingFlags.Instance);
            var appointments = appointmentsField?.GetValue(manager) as List<Appointment>;

            Assert.NotNull(appointments);
            Assert.Contains(appointments, a => a.Id == "DR.Tetelo202566" &&
                                               a.PatientID == "MasokaKarabo2005" &&
                                               a.DoctorName == "DR.Tetelo");
        }

        [Fact]
        public void DeleteAppointment_ShouldReturnTrue_WhenExistingAppointmentIsDeleted() //ensuring that deletion is successful
        {
            //Arrange: create a manager to add an appointment that is to be deleted
            var manager = new AppointmentManager();
            var appointmentToDelete = new Appointment { Id = "A004" };
            manager.AddAppointment(appointmentToDelete);

            //Act: calling the Delete method
            var result = manager.DeleteAppointment("A004");

            //Assert: Checking if the deletion was successful and the appointment is no longer there.
            Assert.True(result);
        }
        [Fact]
        //Negative test - non-existent ID
        public void DeleteAppointment_ShouldReturnFalse_WhenAppointmentIdDoesNotExist()
        {
            // Creating a manager with no appointments (Arrange)
            var manager = new AppointmentManager();

            //Act: attempting to delete an appointment that doesn't exist...
            var result = manager.DeleteAppointment("A005");

            //Assert - showing a result where the deletion can't happen because it does not exist
            Assert.Throws<EntityNotFoundException>(() => result);
            Assert.False(result);
        }
        [Fact]
        //testing ListAll(). First, positive testing: should print appointments when appointments exist
        public void ListAll_ShouldPrintAppointments_WhenAppointmentExist()
        {
            //Arrange: creating a manager, adding mock appointments and preparing to capture the console output
            var manager = new AppointmentManager();
            manager.AddAppointment(new Appointment { Id = "A006", PatientID = "P101" });
            manager.AddAppointment(new Appointment { Id = "A007", PatientID = "P102" });

            var stringWriter = new StringWriter();
            Console.SetOut(stringWriter);

            //Act section: call the ListAll() method showing that it will print the stringWriter
            manager.ListAll();

            //Assert: we ensure and check the output string for the expected text 
            var output = stringWriter.ToString();
            Assert.Contains("A006", output);
            Assert.Contains("P101", output);
            Assert.Contains("A007", output);
            Assert.Contains("P102", output);
        }
        [Fact]
        public void ListAll_ShouldPrint1Appointment_WhenAppointmentExist()
        {
            //Arrange: creating a manager and seeing if it can print only 1 appointment when added. Doesn't need many appointments for printing
            var manager = new AppointmentManager();
            manager.AddAppointment(new Appointment { Id = "A008", PatientID = "P103" });

            var stringWriter = new StringWriter();
            Console.SetOut(stringWriter);

            //Act section: call the ListAll() method showing that it will print the stringWriter
            manager.ListAll();

            //Assert: we ensure and check the output string for the expected text 
            var output = stringWriter.ToString();
            Assert.Contains("A008", output);
            Assert.Contains("P103", output);
        }

        [Fact]
        //Negative testing: showing if it can print an empty list
        public void ListAll_ShouldPrintNoAppointmentsMessage_WhenListIsEmpty()
        {
            //Arrange: Create a new empty manager and pepare for capture in the console output
            var manager = new AppointmentManager();
            var stringWriter = new StringWriter();
            Console.SetOut(stringWriter);

            //Act: Call the ListAll method on the empty string. Seeing if it would actually pull through
            manager.ListAll();

            //Assert: Check if the captured output string for the expected message
            var output = stringWriter.ToString();
            Assert.Contains("No appointments to diaplay.", output);
        }
    }
}